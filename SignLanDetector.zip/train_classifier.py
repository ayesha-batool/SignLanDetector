import pickle
import numpy as np
from collections import Counter
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import seaborn as sns

with open('data.pickle', 'rb') as f:
    data_dict = pickle.load(f)

valid_data = []
valid_labels = []

for d, l in zip(data_dict['data'], data_dict['labels']):
    if len(d) == len(data_dict['data'][0]):
        valid_data.append(d)
        valid_labels.append(l)

X = np.array(valid_data)
y = np.array(valid_labels)

class_counts = Counter(y)
print("\nClass sample counts after preprocessing:")
for label, count in sorted(class_counts.items()):
    print(f"Class '{label}': {count} samples")
x_train, x_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=True, stratify=y)
model = RandomForestClassifier()
model.fit(x_train, y_train)
y_predict = model.predict(x_test)
score = accuracy_score(y_predict, y_test)
print(f'\n{score * 100:.2f}% of samples were classified correctly!')
with open('model.p', 'wb') as f:
    pickle.dump({'model': model}, f)
plt.figure()
plt.bar(['Accuracy'], [score * 100], color='teal')
plt.ylabel('Accuracy (%)')
plt.title('Model Accuracy')
plt.ylim(0, 100)
plt.savefig('accuracy.png')
plt.close()
cm = confusion_matrix(y_test, y_predict, labels=np.unique(y))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=np.unique(y))
fig, ax = plt.subplots(figsize=(8, 6))
disp.plot(ax=ax, cmap='Blues')
plt.title('Confusion Matrix')
plt.savefig('confusion_matrix.png')
plt.close()
classes = np.unique(y)
class_accuracies = {}

for cls in classes:
    mask = (y_test == cls)
    correct_predictions = (y_predict[mask] == y_test[mask]).sum()
    total_actual = mask.sum()
    acc = correct_predictions / total_actual if total_actual > 0 else 0
    class_accuracies[cls] = acc * 100
plt.figure(figsize=(10, 5))
plt.bar(class_accuracies.keys(), class_accuracies.values(), color='green')
plt.ylabel('Accuracy (%)')
plt.xlabel('Class')
plt.title('Class-wise Accuracy')
plt.ylim(0, 100)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.savefig('class_wise_accuracy.png')
plt.close()
plt.figure(figsize=(8, 4))
sns.countplot(x=y)
plt.title('Class Distribution')
plt.xlabel('Class Labels')
plt.ylabel('Number of Samples')
plt.savefig('class_distribution.png')
plt.close()

importances = model.feature_importances_
indices = np.argsort(importances)[-10:] 
plt.figure(figsize=(8, 5))
plt.title("Top 10 Feature Importances")
plt.barh(range(len(indices)), importances[indices], align="center", color='orange')
plt.yticks(range(len(indices)), [f'Feature {i}' for i in indices])
plt.xlabel("Relative Importance")
plt.savefig("feature_importance.png")
plt.close()
