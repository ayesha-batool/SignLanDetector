# import os
# import cv2
# import mediapipe as mp

# # Initialize MediaPipe Hands
# mp_hands = mp.solutions.hands
# mp_drawing = mp.solutions.drawing_utils
# mp_drawing_styles = mp.solutions.drawing_styles

# # Set up the Hands model
# hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.3)

# # Define input and output directories
# DATA_DIR = './data'
# OUTPUT_DIR = './output'

# # Create the output directory if it doesn't exist
# os.makedirs(OUTPUT_DIR, exist_ok=True)

# # Iterate over each subdirectory in the data directory
# for subdir in os.listdir(DATA_DIR):
#     subdir_path = os.path.join(DATA_DIR, subdir)
#     if os.path.isdir(subdir_path):
#         # List all image files in the subdirectory
#         image_files = [f for f in os.listdir(subdir_path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
#         if image_files:
#             # Select the first image file
#             image_path = os.path.join(subdir_path, image_files[0])
#             # Read and convert the image to RGB
#             img = cv2.imread(image_path)
#             if img is None:
#                 continue  # Skip if the image is not read properly
#             img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

#             # Process the image and detect hand landmarks
#             results = hands.process(img_rgb)
#             if results.multi_hand_landmarks:
#                 for hand_landmarks in results.multi_hand_landmarks:
#                     # Draw hand landmarks on the image
#                     mp_drawing.draw_landmarks(
#                         img_rgb,
#                         hand_landmarks,
#                         mp_hands.HAND_CONNECTIONS,
#                         mp_drawing_styles.get_default_hand_landmarks_style(),
#                         mp_drawing_styles.get_default_hand_connections_style()
#                     )

#             # Convert the RGB image back to BGR for saving with OpenCV
#             img_bgr = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)

#             # Define the output path
#             output_path = os.path.join(OUTPUT_DIR, f"{subdir}_landmarked.jpg")

#             # Save the image with landmarks
#             cv2.imwrite(output_path, img_bgr)
#             print(f"Saved landmarked image to {output_path}")
import matplotlib.pyplot as plt

# Simulated realistic data for a CNN model training on sign language dataset
epochs = list(range(1, 21))
train_accuracy = [0.50, 0.62, 0.70, 0.76, 0.82, 0.86, 0.89, 0.91, 0.93, 0.94,
                  0.95, 0.96, 0.96, 0.97, 0.97, 0.97, 0.98, 0.98, 0.98, 0.98]
val_accuracy =   [0.48, 0.60, 0.68, 0.74, 0.79, 0.82, 0.83, 0.84, 0.85, 0.86,
                  0.86, 0.86, 0.85, 0.85, 0.85, 0.84, 0.84, 0.83, 0.83, 0.82]

train_loss =     [1.1, 0.9, 0.75, 0.63, 0.52, 0.45, 0.38, 0.33, 0.29, 0.26,
                  0.23, 0.21, 0.19, 0.18, 0.16, 0.15, 0.14, 0.13, 0.12, 0.11]
val_loss =       [1.2, 1.0, 0.85, 0.70, 0.60, 0.55, 0.52, 0.50, 0.49, 0.48,
                  0.48, 0.49, 0.50, 0.52, 0.54, 0.55, 0.56, 0.58, 0.59, 0.60]

# Plot Accuracy
plt.figure(figsize=(10, 6))
plt.plot(epochs, train_accuracy, label='Training Accuracy', marker='o')
plt.plot(epochs, val_accuracy, label='Validation Accuracy', marker='o')
plt.title('Training vs Validation Accuracy (Realistic)')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)
plt.savefig('realistic_accuracy_graph.png')
plt.close()

# Plot Loss
plt.figure(figsize=(10, 6))
plt.plot(epochs, train_loss, label='Training Loss', marker='o')
plt.plot(epochs, val_loss, label='Validation Loss', marker='o')
plt.title('Training vs Validation Loss (Realistic)')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.savefig('realistic_loss_graph.png')
plt.close()

