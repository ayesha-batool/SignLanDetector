import os
import cv2
import pickle
import mediapipe as mp

# Set up paths and MediaPipe
DATA_DIR = './data'

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.2)  # Lowered confidence

data = []
labels = []

# Loop through each folder and image
for dir_ in os.listdir(DATA_DIR):
    dir_path = os.path.join(DATA_DIR, dir_)
    if not os.path.isdir(dir_path):
        continue  # Skip if it's not a directory

    print(f"Processing directory: {dir_}")

    for img_name in os.listdir(dir_path):
        img_path = os.path.join(dir_path, img_name)
        img = cv2.imread(img_path)

        if img is None:
            print(f"Skipped image (couldn't read): {img_path}")
            continue  # Skip if image not loaded

        print(f"Processing image: {img_name}")
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Convert to RGB for MediaPipe
        results = hands.process(img_rgb)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                x_, y_, data_aux = [], [], []
                for lm in hand_landmarks.landmark:
                    x_.append(lm.x)
                    y_.append(lm.y)

                # Normalize the landmarks relative to the hand's bounding box
                for lm in hand_landmarks.landmark:
                    data_aux.append(lm.x - min(x_))
                    data_aux.append(lm.y - min(y_))

                data.append(data_aux)
                labels.append(dir_)
        else:
            print(f"No hands detected in image: {img_path}")

# Save data
with open('data.pickle', 'wb') as f:
    pickle.dump({'data': data, 'labels': labels}, f)

print(f"✅ Data saved. Total samples: {len(data)}")
# import os
# import cv2
# import pickle
# import mediapipe as mp

# # Constants
# DATA_DIR = './data'  # Your dataset directory
# OUTPUT_FILE = 'data.pickle'

# # MediaPipe setup
# mp_hands = mp.solutions.hands
# mp_drawing = mp.solutions.drawing_utils
# hands = mp_hands.Hands(static_image_mode=False, min_detection_confidence=0.5)

# data = []
# labels = []

# # Loop through each folder (label)
# for dir_ in os.listdir(DATA_DIR):
#     dir_path = os.path.join(DATA_DIR, dir_)
#     if not os.path.isdir(dir_path):
#         continue

#     print(f"📁 Processing directory: {dir_}")

#     # Loop through each image in the folder
#     for img_name in os.listdir(dir_path):
#         img_path = os.path.join(dir_path, img_name)
#         img = cv2.imread(img_path)

#         if img is None:
#             print(f"❌ Skipped image (couldn't read): {img_path}")
#             continue

#         # Resize image for consistent processing
#         img = cv2.resize(img, (640, 480))

#         # Optional: apply CLAHE for better contrast
#         img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#         clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
#         img_clahe = clahe.apply(img_gray)
#         img_rgb = cv2.cvtColor(cv2.merge([img_clahe]*3), cv2.COLOR_BGR2RGB)

#         # Hand detection
#         results = hands.process(img_rgb)

#         if results.multi_hand_landmarks:
#             for hand_landmarks in results.multi_hand_landmarks:
#                 # Draw for visualization
#                 mp_drawing.draw_landmarks(img, hand_landmarks, mp_hands.HAND_CONNECTIONS)

#                 x_, y_, data_aux = [], [], []

#                 for lm in hand_landmarks.landmark:
#                     x_.append(lm.x)
#                     y_.append(lm.y)

#                 for lm in hand_landmarks.landmark:
#                     data_aux.append(lm.x - min(x_))
#                     data_aux.append(lm.y - min(y_))

#                 data.append(data_aux)
#                 labels.append(dir_)

#             # Debug visual: show the image
#             cv2.imshow("Detected Hand", img)
#             cv2.waitKey(100)  # Show for 100 ms
#         else:
#             print(f"⚠️ No hands detected in: {img_path}")

# cv2.destroyAllWindows()

# # Save data
# with open(OUTPUT_FILE, 'wb') as f:
#     pickle.dump({'data': data, 'labels': labels}, f)

# print(f"✅ Data saved to '{OUTPUT_FILE}'. Total samples: {len(data)}")
