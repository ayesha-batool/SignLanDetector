import cv2
import os
from skimage.metrics import structural_similarity as ssim
import numpy as np
import shutil

# Paths
reference_image_path = 'data/0/0.jpg'
dataset_folder = 'sign_A_images'
output_folder = 'matched_A'

# Create output folder
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Load and preprocess reference image
ref_img = cv2.imread(reference_image_path, cv2.IMREAD_GRAYSCALE)
ref_img = cv2.resize(ref_img, (200, 200))

# Loop through dataset images
for filename in os.listdir(dataset_folder):
    img_path = os.path.join(dataset_folder, filename)

    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        continue
    img = cv2.resize(img, (200, 200))

    score, _ = ssim(ref_img, img, full=True)

    # Tune this threshold based on your dataset quality
    if score > 0.75:
        shutil.copy(img_path, os.path.join(output_folder, filename))
        print(f'Matched: {filename} (SSIM: {score:.2f})')

print(f"\nDone! Matching images saved in '{output_folder}'")
